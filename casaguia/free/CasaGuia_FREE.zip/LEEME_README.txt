CasaGuía FREE · Wi-Fi QR cards + House rules sign (ES · EN · DE · FR)
Open the HTML file in your browser, fill in your Wi-Fi name, password and rules, and click "Print / Save PDF".
Abre el archivo HTML en tu navegador, escribe el nombre y la contraseña del Wi-Fi y tus normas, y pulsa "Imprimir / Guardar PDF".
The full version (welcome book in 4 languages, check-out, recycling and welcome signs, thank-you cards with a review QR):
La versión completa (libro de bienvenida en 4 idiomas, carteles de salida, reciclaje y bienvenida, tarjetas de agradecimiento con QR):
https://kitwisestudio.gumroad.com/l/hamqy
QR library: qrcode-generator (MIT), Kazuhiko Arase. "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
